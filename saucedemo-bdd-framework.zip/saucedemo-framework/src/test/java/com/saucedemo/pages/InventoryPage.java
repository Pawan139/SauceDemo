package com.saucedemo.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class InventoryPage extends BasePage {

    @FindBy(css = ".title")
    private WebElement pageTitle;

    @FindBy(css = ".inventory_item")
    private List<WebElement> inventoryItems;

    @FindBy(css = ".shopping_cart_link")
    private WebElement cartIcon;

    @FindBy(css = ".shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(css = "[data-test='product-sort-container']")
    private WebElement sortDropdown;

    @FindBy(id = "react-burger-menu-btn")
    private WebElement menuButton;

    @FindBy(id = "logout_sidebar_link")
    private WebElement logoutLink;

    public boolean isInventoryPageDisplayed() {
        return isDisplayed(pageTitle) && pageTitle.getText().equals("Products");
    }

    public String getPageTitle() {
        return getText(pageTitle);
    }

    public int getProductCount() {
        return inventoryItems.size();
    }

    public void addFirstProductToCart() {
        WebElement addToCartBtn = inventoryItems.get(0)
                .findElement(org.openqa.selenium.By.cssSelector("button"));
        click(addToCartBtn);
    }

    public void addProductToCartByName(String productName) {
        for (WebElement item : inventoryItems) {
            String name = item.findElement(
                    org.openqa.selenium.By.cssSelector(".inventory_item_name")).getText();
            if (name.equalsIgnoreCase(productName)) {
                click(item.findElement(org.openqa.selenium.By.cssSelector("button")));
                return;
            }
        }
        throw new RuntimeException("Product not found: " + productName);
    }

    public String getCartBadgeCount() {
        return isDisplayed(cartBadge) ? getText(cartBadge) : "0";
    }

    public void clickCart() {
        click(cartIcon);
    }

    public void logout() {
        click(menuButton);
        click(logoutLink);
    }
}
