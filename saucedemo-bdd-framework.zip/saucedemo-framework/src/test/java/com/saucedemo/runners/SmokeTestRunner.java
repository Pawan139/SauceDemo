package com.saucedemo.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.saucedemo.stepdefs", "com.saucedemo.hooks"},
        tags = "@Smoke",
        plugin = {
                "pretty",
                "html:test-output/cucumber-reports/smoke-report.html",
                "json:test-output/cucumber-reports/smoke.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true
)
public class SmokeTestRunner extends AbstractTestNGCucumberTests {
}
