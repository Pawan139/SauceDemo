package com.saucedemo.hooks;

import com.saucedemo.utils.DriverManager;
import com.saucedemo.utils.ScreenshotUtil;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        System.out.println("▶ Starting Scenario: " + scenario.getName());
        DriverManager.initDriver();
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            System.out.println("✘ Scenario FAILED: " + scenario.getName());
            // Capture screenshot and attach to Cucumber report
            byte[] screenshot = (byte[]) ((org.openqa.selenium.TakesScreenshot)
                    DriverManager.getDriver())
                    .getScreenshotAs(org.openqa.selenium.OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName());

            // Also save to file
            ScreenshotUtil.captureScreenshot(scenario.getName());
        } else {
            System.out.println("✔ Scenario PASSED: " + scenario.getName());
        }
        DriverManager.quitDriver();
    }
}
