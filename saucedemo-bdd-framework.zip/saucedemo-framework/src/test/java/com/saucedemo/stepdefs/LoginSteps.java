package com.saucedemo.stepdefs;

import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class LoginSteps {

    private LoginPage loginPage = new LoginPage();
    private InventoryPage inventoryPage = new InventoryPage();

    @Given("user is on the SauceDemo login page")
    public void userIsOnLoginPage() {
        loginPage.navigateTo();
        Assert.assertTrue(loginPage.isLoginPageDisplayed(), "Login page not displayed");
    }

    @When("user enters username {string} and password {string}")
    public void userEntersCredentials(String username, String password) {
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
    }

    @When("user clicks the login button")
    public void userClicksLoginButton() {
        loginPage.clickLogin();
    }

    @Then("user should be redirected to the inventory page")
    public void userShouldBeOnInventoryPage() {
        Assert.assertTrue(inventoryPage.isInventoryPageDisplayed(),
                "User was not redirected to inventory page");
    }

    @Then("the page title should be {string}")
    public void pageTitleShouldBe(String expectedTitle) {
        Assert.assertEquals(inventoryPage.getPageTitle(), expectedTitle,
                "Page title mismatch");
    }

    @Then("an error message should be displayed")
    public void errorMessageShouldBeDisplayed() {
        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message not displayed");
    }

    @Then("the error message should contain {string}")
    public void errorMessageShouldContain(String expectedText) {
        Assert.assertTrue(loginPage.getErrorMessage().contains(expectedText),
                "Error message mismatch. Actual: " + loginPage.getErrorMessage());
    }

    @When("user logs out")
    public void userLogsOut() {
        inventoryPage.logout();
    }

    @Then("user should be on the login page")
    public void userShouldBeOnLoginPage() {
        Assert.assertTrue(loginPage.isLoginPageDisplayed(), "User is not on login page");
    }
}
