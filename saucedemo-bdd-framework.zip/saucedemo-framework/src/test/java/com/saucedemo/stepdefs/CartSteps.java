package com.saucedemo.stepdefs;

import com.saucedemo.pages.CartPage;
import com.saucedemo.pages.InventoryPage;
import com.saucedemo.pages.LoginPage;
import com.saucedemo.utils.ConfigReader;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class CartSteps {

    private LoginPage loginPage = new LoginPage();
    private InventoryPage inventoryPage = new InventoryPage();
    private CartPage cartPage = new CartPage();

    @Given("user logs in with standard credentials")
    public void userLogsInWithStandardCredentials() {
        loginPage.login(ConfigReader.getStandardUser(), ConfigReader.getPassword());
        Assert.assertTrue(inventoryPage.isInventoryPageDisplayed(),
                "Login failed - inventory page not displayed");
    }

    @When("user adds {string} to the cart")
    public void userAddsProductToCart(String productName) {
        inventoryPage.addProductToCartByName(productName);
    }

    @Then("the cart badge should show {string}")
    public void cartBadgeShouldShow(String expectedCount) {
        Assert.assertEquals(inventoryPage.getCartBadgeCount(), expectedCount,
                "Cart badge count mismatch");
    }

    @When("user clicks on the cart icon")
    public void userClicksCartIcon() {
        inventoryPage.clickCart();
    }

    @Then("user should be on the cart page")
    public void userShouldBeOnCartPage() {
        Assert.assertTrue(cartPage.isCartPageDisplayed(), "Cart page not displayed");
    }

    @Then("the cart should contain {string} item")
    public void cartShouldContainItems(String expectedCount) {
        Assert.assertEquals(cartPage.getCartItemCount(), Integer.parseInt(expectedCount),
                "Cart item count mismatch");
    }
}
