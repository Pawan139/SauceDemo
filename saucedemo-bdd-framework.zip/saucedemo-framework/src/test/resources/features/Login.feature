@Login
Feature: SauceDemo Login Functionality

  Background:
    Given user is on the SauceDemo login page

  @ValidLogin @Smoke
  Scenario: Successful login with valid credentials
    When user enters username "standard_user" and password "secret_sauce"
    And user clicks the login button
    Then user should be redirected to the inventory page
    And the page title should be "Products"

  @InvalidLogin @Regression
  Scenario: Login with invalid credentials
    When user enters username "invalid_user" and password "wrong_pass"
    And user clicks the login button
    Then an error message should be displayed
    And the error message should contain "Username and password do not match"

  @LockedUser @Regression
  Scenario: Login with locked out user
    When user enters username "locked_out_user" and password "secret_sauce"
    And user clicks the login button
    Then an error message should be displayed
    And the error message should contain "Sorry, this user has been locked out"

  @EmptyFields @Regression
  Scenario: Login with empty username
    When user enters username "" and password "secret_sauce"
    And user clicks the login button
    Then an error message should be displayed
    And the error message should contain "Username is required"

  @Logout @Smoke
  Scenario: Successful logout after login
    When user enters username "standard_user" and password "secret_sauce"
    And user clicks the login button
    Then user should be redirected to the inventory page
    When user logs out
    Then user should be on the login page
