@Cart
Feature: SauceDemo Shopping Cart Functionality

  Background:
    Given user is on the SauceDemo login page
    And user logs in with standard credentials

  @AddToCart @Smoke
  Scenario: Add a product to cart
    When user adds "Sauce Labs Backpack" to the cart
    Then the cart badge should show "1"

  @CartPage @Regression
  Scenario: Verify cart page contents
    When user adds "Sauce Labs Backpack" to the cart
    And user clicks on the cart icon
    Then user should be on the cart page
    And the cart should contain "1" item

  @MultipleItems @Regression
  Scenario: Add multiple products to cart
    When user adds "Sauce Labs Backpack" to the cart
    And user adds "Sauce Labs Bike Light" to the cart
    Then the cart badge should show "2"
