# SauceDemo BDD Automation Framework

Selenium + Cucumber BDD + TestNG + ExtentReports framework for SauceDemo testing.

## Tech Stack
- Java 17
- Selenium 4
- Cucumber 7 (BDD)
- TestNG
- Maven
- ExtentReports 5
- WebDriverManager

## Project Structure
```
saucedemo-bdd-framework/
├── src/test/java/com/saucedemo/
│   ├── pages/          # Page Object Model classes
│   ├── stepdefs/       # Cucumber Step Definitions
│   ├── hooks/          # Before/After hooks + screenshots
│   ├── runners/        # TestNG Cucumber Runners
│   └── utils/          # DriverManager, ConfigReader, ScreenshotUtil
├── src/test/resources/
│   ├── features/       # Cucumber .feature files
│   ├── config/         # config.properties
│   └── extent.properties
├── testng.xml
├── Jenkinsfile
└── pom.xml
```

## How to Run

### Run All Tests
```bash
mvn clean test
```

### Run Smoke Tests Only
```bash
mvn clean test -Dcucumber.filter.tags="@Smoke"
```

### Run in Headless Mode
```bash
mvn clean test -Dheadless=true
```

### Run via Jenkins
- Import this project into Jenkins as a Pipeline job
- Point to the Jenkinsfile
- Choose browser, tags, and headless mode from parameters

## Test Reports
After execution, reports are generated at:
- `test-output/ExtentReport.html` — Extent HTML Report
- `test-output/cucumber-reports/cucumber.html` — Cucumber HTML Report
- `test-output/screenshots/` — Screenshots on failure

## Tags Available
| Tag | Description |
|---|---|
| @Smoke | Critical happy path tests |
| @Regression | Full regression suite |
| @Login | Login related tests |
| @Cart | Cart related tests |
| @ValidLogin | Valid login scenario |
| @InvalidLogin | Invalid login scenario |
| @LockedUser | Locked user scenario |
